#!/bin/bash
sudo apt-get install ros-noetic-joint-state-publisher-gui
sudo apt-get install ros-noetic-joy
sudo apt-get install ros-noetic-hector-mapping
sudo apt-get install ros-noetic-gmapping
sudo apt-get install ros-noetic-navigation
sudo apt-get install ros-noetic-cv-bridge
sudo apt-get install ros-noetic-audio-common
sudo apt-get install ros-noetic-controller-manager